<?php include "include/header.php"?>
<?php include "include/navbar.php"?>
<!-- first-section starts here -->
<section class="section first-section">
<div class="container-fluid">
<div class="masonry-blog clearfix">
<?php
$i = 1;
$rows = $db->fetchAll('SELECT * FROM tbl_post INNER JOIN tbl_category ON tbl_post.cat=tbl_category.cat_id WHERE f_post = ? ORDER BY id DESC', ['1']);
foreach($rows as $row){
    if($i == 1){ ?>
        <div class="left-side">
            <div class="masonry-box post-media">
                <img src="uploads/534x468/<?= $row->image?>" alt="" class="img-fluid">
                <div class="shadoweffect">
                    <div class="shadow-desc">
                        <div class="blog-meta">
                            <span class="bg-aqua"><a href="category.php?catid=<?= $row->cat?>&page=1" title=""><?= $row->cat_name?></a></span>
                            <h4><a href="page.php?postid=<?= $row->id?>" title=""><?= $row->title;?></a></h4>
                            <small><a href="page.php?postid=<?= $row->id?>" title=""><?= $helper->formatDate($row->date) ?></a></small>
                            <small><a href="blog-author.php?authid=<?= $row->userid?>&pageid=1" title=""><?= $row->author?></a></small>
                        </div><!-- end meta -->
                    </div><!-- end shadow-desc -->
                </div><!-- end shadow -->
            </div><!-- end post-media -->
        </div><!-- end left-side -->
        <?php }elseif($i == 2){ ?>
        <div class="center-side">
            <div class="masonry-box post-media">
                <img src="uploads/533x261/<?= $row->image?>" alt="" class="img-fluid">
                <div class="shadoweffect">
                    <div class="shadow-desc">
                        <div class="blog-meta">
                            <span class="bg-green"><a href="category.php?catid=<?= $row->cat?>&page=1" title=""><?=$row->cat_name?></a></span>
                            <h4><a href="page.php?postid=<?= $row->id?>" title=""><?= $row->title?></a></h4>
                            <small><a href="page.php?postid=<?= $row->id?>" title=""><?= $helper->formatDate($row->date) ?></a></small>
                            <small><a href="blog-author.php?authid=<?= $row->userid?>&pageid=1" title=""><?= $row->author?></a></small>
                        </div><!-- end meta -->
                    </div><!-- end shadow-desc -->
                </div><!-- end shadow -->
            </div><!-- end post-media -->
        <?php }elseif($i == 3){ ?>
        <div class="masonry-box small-box post-media">
            <img src="uploads/800x598/<?= $row->image?>" alt="" class="img-fluid">
            <div class="shadoweffect">
                <div class="shadow-desc">
                    <div class="blog-meta">
                        <span class="bg-green"><a href="category.php?catid=<?= $row->cat?>&page=1" title=""><?= $row->cat_name?></a></span>
                        <h4><a href="page.php?postid=<?= $row->id?>" title=""><?= $row->title?></a></h4>
                    </div><!-- end meta -->
                </div><!-- end shadow-desc -->
            </div><!-- end shadow -->
        </div><!-- end post-media -->
    <?php }elseif($i == 4){ ?>
        <div class="masonry-box small-box post-media">
            <img src="uploads/800x598/<?= $row->image?>" alt="" class="img-fluid">
            <div class="shadoweffect">
                <div class="shadow-desc">
                    <div class="blog-meta">
                        <span class="bg-green"><a href="category.php?catid=<?= $row->cat?>&page=1" title=""><?= $row->cat_name?></a></span>
                        <h4><a href="page.php?postid=<?= $row->id?>" title=""><?= $row->title?></a></h4>
                    </div><!-- end meta -->
                </div><!-- end shadow-desc -->
            </div><!-- end shadow -->
        </div><!-- end post-media -->
        </div><!-- end left-side -->
        <?php }elseif($i == 5){ ?>
        <div class="right-side hidden-md-down">
            <div class="masonry-box post-media">
                <img src="uploads/534x468/<?= $row->image?>" alt="" class="img-fluid">
                <div class="shadoweffect">
                    <div class="shadow-desc">
                        <div class="blog-meta">
                            <span class="bg-aqua"><a href="category.php?catid=<?= $row->cat?>&page=1" title=""><?= $row->cat_name?></a></span>
                            <h4><a href="page.php?postid=<?= $row->id?>" title=""><?= $row->title?></a></h4>
                            <small><a href="page.php?postid=<?= $row->id?>" title=""><?= $helper->formatDate($row->date) ?></a></small>
                            <small><a href="blog-author.php?authid=<?= $row->userid?>&pageid=1" title=""><?= $row->author?></a></small>
                        </div><!-- end meta -->
                    </div><!-- end shadow-desc -->
                </div><!-- end shadow -->
            </div><!-- end post-media -->
        </div><!-- end right-side -->
        <?php } $i++; } ?>
</div><!-- end masonry -->
</div>
</section>
<!-- first-section starts here -->



<section class="section">
<div class="container">
<div class="row">
<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
    <div class="section-title">
        <?php 
        $cat = $db->fetch("SELECT * FROM tbl_home WHERE id = ?", ['1']);
        $title = $db->fetch("SELECT * FROM tbl_category where cat_id = ?", [$cat->show_home_id]);
        ?>
        <h3 class="color-aqua"><a href="category.php?catid=<?= $title->cat_id?>&page=1" title=""><?= $title->cat_name ?></a></h3>
    </div><!-- end title -->

    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <?php
                $rows = $db->fetchAll('SELECT * FROM tbl_post INNER JOIN tbl_category ON tbl_post.cat=tbl_category.cat_id WHERE  cat = ? ORDER BY id DESC limit 2', [$cat->show_home_id]);
                foreach($rows as $row){ ?>
            <div class="blog-box">
                <div class="post-media">
                    <a href="page.php?postid=<?= $row->id?>" title="">
                        <img src="uploads/1024x550/<?= $row->image?>" alt="" class="img-fluid">
                        <div class="hovereffect">
                            <span></span>
                        </div><!-- end hover -->
                    </a>
                </div><!-- end media -->
                <div class="blog-meta big-meta">
                    <h4><a href="page.php?postid=<?= $row->id?>" title=""><?= $row->title?></a></h4>
                    <!-- shorten body -->
                    <p><?= $helper->textShort($row->content, 300)?></p>
                    <small><a href="category.php?catid=<?= $row->cat?>&page=1" title=""><?= $row->cat_name?></a></small>
                    <small><a href="page.php?postid=<?= $row->id?>" title=""><?= $helper->formatDate($row->date)?></a></small>
                    <small><a href="blog-author.php?authid=<?= $row->userid?>&pageid=1" title=""><?= $row->author?></a></small>
                </div><!-- end meta -->
            </div><!-- end blog-box -->
            <hr class="invis">
                <?php } ?><!--loop ends here-->
        </div><!-- end col -->
    </div><!-- end row -->
</div><!-- end col -->

<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
    <div class="section-title">
    <?php 
        $cat = $db->fetch("SELECT * FROM tbl_home WHERE id = ?", ['2']);
        $title = $db->fetch("SELECT * FROM tbl_category where cat_id = ?", [$cat->show_home_id]);
        ?>
        <h3 class="color-pink"><a href="category.php?catid=<?= $title->cat_id?>&page=1" title=""><?= $title->cat_name?></a></h3>
    </div><!-- end title -->
    <div class="row">
        <?php
            $rows = $db->fetchAll('SELECT * FROM tbl_post INNER JOIN tbl_category ON tbl_post.cat = tbl_category.cat_id WHERE cat= ? ORDER BY id DESC limit 4', [$cat->show_home_id]);
            if($row){
            foreach($rows as $row){ ?>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="blog-box">
                        <div class="post-media">
                            <a href="page.php?postid=<?= $row->id?>" title="">
                                <img src="uploads/690x1024/<?= $row->image?>" alt="" class="img-fluid">
                                <div class="hovereffect">
                                    <span></span>
                                </div><!-- end hover -->
                            </a>
                        </div><!-- end media -->
                        <div class="blog-meta">
                            <h4><a href="page.php?postid=<?= $row->id?>" title=""><?= $row->title?></a></h4>
                            <small><a href="category.php?catid=<?= $row->cat?>&page=1" title=""><?= $row->cat_name?></a></small>
                            <small><a href="page.php?catid=<?= $row->id?>&page=1" title=""><?= $helper->formatDate($row->date)?></a></small>
                        </div><!-- end meta -->
                    </div><!-- end blog-box -->
                    <hr class="invis">
                </div><!-- end col -->
            <?php } } ?><!-- loop end row -->
    </div><!-- end row -->
</div><!-- end col -->
</div><!-- end row -->

<!-- banner start here -->
<hr class="invis1">

<div class="row">
<div class="col-lg-10 offset-lg-1">
    <div class="banner-spot clearfix">
        <div class="banner-img">
            <img src="upload/banner_01.jpg" alt="" class="img-fluid">
        </div><!-- end banner-img -->
    </div><!-- end banner -->
</div><!-- end col -->
</div><!-- end row -->

<hr class="invis1">

<div class="row">
<div class="col-lg-9">
    <div class="blog-list clearfix">
        <div class="section-title">
        <?php 
        $cat = $db->fetch("SELECT * FROM tbl_home WHERE id = ?", ['3']);
        $title = $db->fetch("SELECT * FROM tbl_category where cat_id = ?", [$cat->show_home_id]);
        ?>
            <h3 class="color-green"><a href="category.php?catid=<?= $title->cat_id?>&page=1" title=""><?= $title->cat_name?></a></h3>
        </div><!-- end title -->
        <?php
        $rows = $db->fetchAll('SELECT * FROM tbl_post INNER JOIN tbl_category ON tbl_post.cat=tbl_category.cat_id WHERE cat = ? ORDER BY id DESC limit 4', [$cat->show_home_id]);
        if($rows){
        foreach($rows as $row){ ?>
        <div class="blog-box row">
            <div class="col-md-4">
                <div class="post-media">
                    <a href="page.php?postid=<?= $row->id?>" title="">
                        <img src="uploads/800x800/<?= $row->image?>" alt="" class="img-fluid">
                        <div class="hovereffect"></div>
                    </a>
                </div><!-- end media -->
            </div><!-- end col -->

            <div class="blog-meta big-meta col-md-8">
                <h4><a href="page.php?postid=<?= $row->id?>" title=""><?= $row->title?></a></h4>
                <p><?= $helper->textShort($row->content, 200)?></p>
                <small><a href="category.php?catid=<?= $row->cat?>&page=1" title=""><?= $row->cat_name?></a></small>
                <small><a href="page.php?postid=<?= $row->id?>" title=""><?= $helper->formatDate($row->date)?></a></small>
                <small><a href="blog-author.php?authid=<?= $row->userid?>&pageid=1" title=""><?= $row->author?></a></small>
            </div><!-- end meta -->
        </div><!-- end blog-box -->
        <hr class="invis">
        <?php } } ?><!-- loop end  -->
    </div><!-- end blog-list -->

    <hr class="invis">

    <div class="blog-list clearfix">
        <div class="section-title">
        <?php 
        $cat = $db->fetch("SELECT * FROM tbl_home WHERE id = ?", ['4']);
        $title = $db->fetch("SELECT * FROM tbl_category where cat_id = ?", [$cat->show_home_id]);
        ?>
            <h3 class="color-red"><a href="category.php?catid=<?= $title->cat_id?>&page=1" title=""><?= $title->cat_name?></a></h3>
        </div><!-- end title -->
<?php
    $rows = $db->fetchAll('SELECT * from tbl_post INNER JOIN tbl_category ON tbl_post.cat=tbl_category.cat_id WHERE cat = ? ORDER BY id DESC limit 4', [$cat->show_home_id]);
    if($rows){
        foreach($rows as $row){
            ?>
        <div class="blog-box row">
        <div class="col-md-4">
            <div class="post-media">
                <a href="page.php?postid=<?= $row->id?>" title="">
                    <img src="uploads/800x800/<?= $row->image?>" alt="" class="img-fluid">
                    <div class="hovereffect"></div>
                </a>
            </div><!-- end media -->
        </div><!-- end col -->

        <div class="blog-meta big-meta col-md-8">
            <h4><a href="page.php?postid=<?= $row->id?>" title=""><?= $row->title?></a></h4>
            <p><?= $helper->textShort($row->content, 200)?></p>
            <small><a href="category.php?catid=<?= $row->cat?>&page=1" title=""><?= $row->cat_name?></a></small>
            <small><a href="page.php?postid=<?= $row->id?>" title=""><?= $helper->formatDate($row->date)?></a></small>
            <small><a href="blog-author.php?authid=<?= $row->userid?>&pageid=1" title=""><?= $row->author?></a></small>
        </div><!-- end meta -->
        </div><!-- end blog-box -->
        <hr class="invis">
        <?php } } ?>

    </div><!-- end blog-list -->
</div><!-- end col -->

<div class="col-lg-3">
        <?php 
        $cat = $db->fetch("SELECT * FROM tbl_home WHERE id = ?", ['5']);
        $title = $db->fetch("SELECT * FROM tbl_category where cat_id = ?", [$cat->show_home_id]);
        ?>
    <div class="section-title">
        <h3 class="color-yellow"><a href="category.php?catid=<?= $title->cat_id?>&page=1" title=""><?= $title->cat_name?></a></h3>
    </div><!-- end title -->
    <?php
    $rows = $db->fetchAll('SELECT * FROM tbl_post INNER JOIN tbl_category ON tbl_post.cat=tbl_category.cat_id WHERE cat = ? ORDER BY id DESC limit 3', [$cat->show_home_id]);
    if($row){ foreach($rows as $row){ ?>
    <div class="blog-box">
        <div class="post-media">
            <a href="page.php?postid=<?= $row->id?>" title="">
                <img src="uploads/800x460/<?= $row->image?>" alt="" class="img-fluid">
                <div class="hovereffect">
                    <span class="videohover"></span>
                </div><!-- end hover -->
            </a>
        </div><!-- end media -->
        <div class="blog-meta">
            <h4><a href="single.html" title=""><?= $row->title?></a></h4>
            <small><a href="category.php?catid=<?= $row->cat?>&page=1" title=""><?=$row->cat_name?></a></small>
            <small><a href="page.php?postid=<?= $row->id?>" title=""><?= $helper->formatDate($row->date)?></a></small>
        </div><!-- end meta -->
    </div><!-- end blog-box -->
    <hr class="invis">
    <?php } } ?>



    <div class="section-title">
        <?php 
        $cat = $db->fetch("SELECT * FROM tbl_home WHERE id = ?", ['6']);
        $title = $db->fetch("SELECT * FROM tbl_category where cat_id = ?", [$cat->show_home_id]);
        ?>
        <h3 class="color-grey"><a href="categroy.php?catid=<?= $title->cat_id?>&page=1" title=""><?= $title->cat_name?></a></h3>
    </div><!-- end title -->
        <?php
        $rows = $db->fetchAll('SELECT * FROM tbl_post INNER JOIN tbl_category ON tbl_post.cat=tbl_category.cat_id WHERE cat = ? ORDER BY id DESC limit 3', [$cat->show_home_id]);
        if($rows){
            foreach($rows as $row){
                ?>
    <div class="blog-box">
        <div class="post-media">
            <a href="page.php?postid=<?= $row->id?>" title="">
                <img src="uploads/800x460/<?= $row->image?>" alt="" class="img-fluid">
                <div class="hovereffect">
                    <span></span>
                </div><!-- end hover -->
            </a>
        </div><!-- end media -->
        <div class="blog-meta">
            <h4><a href="page.php?postid=<?= $row->id?>" title=""><?= $row->title?></a></h4>
            <small><a href="category.php?catid=<?= $row->cat?>&page=1" title=""><?= $row->cat_name?></a></small>
            <small><a href="page.php?postid=<?= $row->id?>" title=""><?= $helper->formatDate($row->date)?></a></small>
        </div><!-- end meta -->
    </div><!-- end blog-box -->
    <hr class="invis">
<?php } } ?>
</div><!-- end col -->
</div><!-- end row -->

<hr class="invis1">

<div class="row">
<div class="col-lg-10 offset-lg-1">
    <div class="banner-spot clearfix">
        <div class="banner-img">
            <img src="upload/banner_02.jpg" alt="" class="img-fluid">
        </div><!-- end banner-img -->
    </div><!-- end banner -->
</div><!-- end col -->
</div><!-- end row -->
</div><!-- end container -->
</section>
<?php include "include/footer.php"?>