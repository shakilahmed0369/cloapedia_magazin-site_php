<?php

class Helper {
  //date formator
  public function formatDate($data){
    $timestamp = strtotime($data);
    return date('d F, Y', $timestamp); 
  }

  //text shortener
  public function textShort($text, $limit=400){
    $str = substr($text, 0, $limit);
    return preg_replace('/\W\w+\s*(\W*)$/', '$1', $str).'....';
    
  }

  //getting category
  public static function get_cat($id,$offset, $limit){
  $db = new Database();
  return $db->fetchAll("SELECT * FROM tbl_category WHERE show_nav_cat = {$id} limit $offset, $limit");
  
}
//geting post
  public static function get_post($catid, $offset, $limit){
  $db = new Database();
  return $db->fetchAll("SELECT * FROM tbl_post WHERE cat = {$catid} && n_c_post = 1 limit {$offset}, {$limit}");
}

//uniq image name genaretor
  public static function imgName($name){
  return rand(4, 1000).'-'.$name;
}

// image upload dir
  public static function imgDest($folder,$name){
    $data = "../uploads/$folder/$name";
    return $data;
}

//input xss protect
public static function inCheck($data){
  $data = trim($data);
  $data = stripslashes($data); 
  $data = htmlspecialchars($data);
  return $data;
} 

//social link updatae
public static function social($name, $link){
  $db = new Database();
  return $db->update("UPDATE tbl_social SET {$name} = ? WHERE id = ?", [$link, 1]);
}

public static function socialShow(){
  $db = new Database();
  return $db->fetch("SELECT * FROM tbl_social WHERE id = ?", [1]);
}

public static function showcat($data){
  $db = new Database();
  $sql = $db->fetch("SELECT cat_name FROM tbl_category WHERE cat_id = ?", [$data]);
  return $sql->cat_name;
}

//show logo

public static function logo(){
  $db = new Database();
  $logo = $db->fetch("SELECT * FROM tbl_logo WHERE id = ?", [1]);
  return $logo->logo;
}











}