<?php
class Validate {
  public static $error = [];

  //image vlaidation
  public static function imageVal($file){
    if(empty($file['image'])){
    self::addError('image', 'Image fild must not be empty!'); 
    }elseif(!($file['image']['type'] == "image/png" || $file['image']['type'] == "image/jpeg" || $file['image']['type'] == "image/gif")){
    self::addError('image', 'Image must be a valid image'); 
    }
  }

  //social link validation

  public static function social($data){
    $fb = $data['fb'];
    $twt = $data['twt'];
    $ins = $data['ins'];
    $pen = $data['pen'];
    $fl = $data['fl'];

    if(!(filter_var($fb, FILTER_VALIDATE_URL))){
      self::addError('fb', 'Worng facebook URL');
    }

  }


  //validate add post filds

  public static function checkpost($file,$image){
    //title
    $title = Helper::inCheck($file['title']);
    $cat = Helper::inCheck($file['cat']);
    $editor = Helper::inCheck($file['editor1']);
    $tags = Helper::inCheck($file['tags']);

    if(empty($title) || empty($cat) || empty($editor)|| empty($tags)){
      self::addError('allerror', 'All fild must be filed');
    }
    self::imageVal($image);

  }

  public static function checkEditpost($file){
    //title
    $title = Helper::inCheck($file['title']);
    $cat = Helper::inCheck($file['cat']);
    $editor = Helper::inCheck($file['editor1']);
    $tags = Helper::inCheck($file['tags']);

    if(empty($title) || empty($cat) || empty($editor)|| empty($tags)){
      self::addError('allerror', 'All fild must be filed');
    }
    

  }




  public static function addError($key, $value){
    return self::$error[$key] = $value;
  }























}