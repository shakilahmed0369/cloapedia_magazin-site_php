<?php
if(!isset($_REQUEST['search']) || $_REQUEST['search'] == null){
    header("location: 404.php");
}else{
}
$search = $_REQUEST['search'];
?>
<?php include "include/header.php"?>
<?php include "include/navbar.php"?>





        <div class="page-title wb">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                        <?php
                        //$cat = $db->fetch("SELECT * FROM tbl_category WHERE cat_id = ?", [$catid]);
                        ?>
                        <h2><i class="fa fa-shopping-bag bg-red"></i> Search Result<small class="hidden-xs-down hidden-sm-down">Nulla felis eros, varius sit amet volutpat non. </small></h2>
                    </div><!-- end col -->
                  
                </div><!-- end row -->
            </div><!-- end container -->
        </div><!-- end page-title -->

        <section class="section wb">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 col-md-12 col-sm-12 col-xs-12">
                        <div class="page-wrapper">
                            <div class="blog-list clearfix">
                            <?php
                            $posts = $db->fetchAll("SELECT * FROM tbl_post WHERE title LIKE '%$search%' OR tags LIKE '%$search%'");

                           foreach($posts as $post):
                            ?>

                                <div class="blog-box row">
                                    <div class="col-md-4">
                                        <div class="post-media">
                                            <a href="single.html" title="">
                                                <img src="uploads/800x800/<?= $post->image?>" alt="" class="img-fluid">
                                                <div class="hovereffect"></div>
                                            </a>
                                        </div><!-- end media -->
                                    </div><!-- end col -->
                                    <div class="blog-meta big-meta col-md-8">
                                        <h4><a href="page.php?postid=<?= $post->id?>" title=""><?= $post->title?></a></h4>
                                        <p><?= $helper->textShort($post->content, 200)?></p>
                                        <small><a href="blog-category-01.html" title=""><?= Helper::showcat($post->cat)?></a></small>
                                        <small><a href="" title=""><?= $helper->formatDate($post->date)?></a></small>
                                        <small><a href="blog-author.html" title=""><?= $post->author?></a></small>
                                    </div><!-- end meta -->
                                </div><!-- end blog-box -->
                                <hr class="invis">
                                <?php endforeach?>


                                <div class="row">
                                    <div class="col-lg-10 offset-lg-1">
                                        <div class="banner-spot clearfix">
                                            <div class="banner-img">
                                                <img src="upload/banner_02.jpg" alt="" class="img-fluid">
                                            </div><!-- end banner-img -->
                                        </div><!-- end banner -->
                                    </div><!-- end col -->
                                </div><!-- end row -->


                        
                            </div><!-- end blog-list -->
                        </div><!-- end page-wrapper -->

                        <hr class="invis">

                    </div><!-- end col -->

                    <!-- sidebar starts here -->
                    <?php include "include/sidebar.php"?>
                    <!-- sidebar End here -->

                </div><!-- end row -->
            </div><!-- end container -->
        </section>
<?php include "include/footer.php"?>