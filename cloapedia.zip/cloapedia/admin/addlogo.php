<?php include "include/header.php"?>
<?php

if(isset($_REQUEST['submit'])){
  $errors = Validate::$error;
  if(isset($_FILES['image'])){
    
    Validate::imageVal($_FILES);
    if(empty($errors['image'])){
      $tmpName = $_FILES['image']['tmp_name'];
      //$imgName = Helper::imgName($_FILES['image']['name']);
      $sql = $db->update("UPDATE tbl_logo SET logo = ? WHERE id = ?", ['logo.png', '1']);
      move_uploaded_file($tmpName, Helper::imgDest('logo', 'logo.png'));
      if($sql){
        $msg = true;
      }
    }
  
  }
}
$logo = $db->fetch('SELECT * FROM tbl_logo WHERE id = ?', ['1']);

?>
        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Page</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item">Site option</li>
              <li class="breadcrumb-item active" aria-current="page">Add logo</li>
            </ol>
          </div>

          <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Add LOGO</h6>
                </div>
                <div class="card-body">
                <div class="row">
                <div style="border-right: 1px solid #7babec" class="col-md-6">
                 <form action="" method="POST" enctype="multipart/form-data">
                 <?php if(isset($msg)):?>
                   <div class="alert alert-success alert-dismissible" role="alert">
                   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                     <span aria-hidden="true">×</span>
                   </button>
                   LOGO Updated <b>Successfully!</b>
                 </div>
                 <?php endif;?>
                    <div class="form-group  mb-0">
                      <div class="custom-file">
                        <input name="image" type="file" class="custom-file-input" id="customFile">
                        <label style="box-shadow: none !important; z-index: 0;" class="custom-file-label" for="customFile">Choose file</label>
                        <small class=" form-text text-danger"><?= @Validate::$error['image']?></small>
                      </div>
                    </div>
                      <!-- submit button -->
                    <button name="submit" type="submit" class="btn btn-primary px-5 mt-4"><b>Save</b></button>
                  </form>
                 </div>
                 <div class="col-md-6">
                  <img class=" img-fluid" src="<?= Helper::imgDest('logo', $logo->logo)?>" alt="" srcset="">
                 </div>
                </div> 
                </div>
              </div>
        </div>
        <!---Container Fluid-->
      </div>
<?php include "include/footer.php"?>