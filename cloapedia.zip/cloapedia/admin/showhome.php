<?php include "include/header.php"?>
<?php
  if(isset($_REQUEST['submit'])){
    $error = '';
    $lists = $db->fetchAll("SELECT * FROM tbl_home");
    foreach( $lists as $list){
      if(empty($_REQUEST[$list->id])){
        $error = 'All Filds must be selected!';
      }
    }
    
    if(empty($error)){
      foreach($lists as $list):
        $id = $list->id;
        $cat_id = $_REQUEST[$list->id];
        $db->update("UPDATE tbl_home SET show_home_id = ? WHERE id = ?", [$cat_id, $id]);
        endforeach;
        $msg=true;
    }
  }
?>
        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Page</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item">Pages</li>
              <li class="breadcrumb-item active" aria-current="page">Blank Page</li>
            </ol>
          </div>

          <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Form Basic</h6>
                </div>
                <div class="card-body">
                <?php if(isset($msg)):?>
                    <div class="alert alert-success alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                      Category Inserted <b>Successfully!</b>
                  </div>
                  <?php elseif(isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                      <?= $error?>
                  </div>
                    <?php endif ?>
                  <form action="" method="POST">
                    <!-- 1st section -->
                    <?php
                      $shows = $db->fetchAll("SELECT * FROM tbl_home");
                      $i = 1;
                      foreach($shows as $show ):?>
                    <div class="form-group">
                      <label for="exampleFormControlSelect1">Section <?= $i?></label>
                      <select name="<?= $show->id?>" class="form-control" id="exampleFormControlSelect1">
                        <option value="0">Select</option>
                        <?php
                        $show_cat = $db->fetchAll('SELECT * FROM tbl_category');
                        foreach($show_cat as $cat):?>
                        <option 
                        <?php if($show->show_home_id == $cat->cat_id){echo 'selected';}?>
                        value="<?= $cat->cat_id?>"><?= $cat->cat_name?>
                        </option>
                        <?php endforeach?>
                      </select>
                    </div>
                    <?php $i++; endforeach?>

                      <!-- submit button -->
                    <button name="submit" type="submit" class="btn btn-primary px-5 mt-4"><b>POST</b></button>
                  </form>
                </div>
              </div>
        </div>
        <!---Container Fluid-->
      </div>
<?php include "include/footer.php"?>