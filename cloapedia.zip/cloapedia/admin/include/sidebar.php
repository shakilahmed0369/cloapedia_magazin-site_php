    <!-- Sidebar -->
    <ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar">
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        <div class="sidebar-brand-icon">
          <img src="img/logo/logo2.png">
        </div>
        <div class="sidebar-brand-text mx-3">RuangAdmin</div>
      </a>
      <hr class="sidebar-divider my-0">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>
      <hr class="sidebar-divider">
      <?php if(Session::get('role') == 1 || Session::get('role') == 3):?>
      <div class="sidebar-heading">
        Main Options
      </div>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseBootstrap"
          aria-expanded="true" aria-controls="collapseBootstrap">
          <i class="far fa-fw fa-window-maximize"></i>
          <span>Site Options</span>
        </a>
        <div id="collapseBootstrap" class="collapse" aria-labelledby="headingBootstrap" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Site Options</h6>
            <a class="collapse-item" href="addlogo.php">Logo</a>
            <a class="collapse-item" href="social.php">Social media</a>
          </div>
        </div>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseBootstrap2"
          aria-expanded="true" aria-controls="collapseBootstrap2">
          <i class="fas fa-house-damage"></i>
          <span>Home Page</span>
        </a>
        <div id="collapseBootstrap2" class="collapse" aria-labelledby="headingBootstrap" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Home Options</h6>
            <a class="collapse-item" href="showhome.php">Home Settings</a>
          </div>
        </div>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#category-option"
          aria-expanded="true" aria-controls="category-option">
          <i class="fas fa-columns"></i>
          <span>Category Option</span>
        </a>
        <div id="category-option" class="collapse" aria-labelledby="headingBootstrap" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Category Option</h6>
            <a class="collapse-item" href="addcat.php">Add Category</a>
            <a class="collapse-item" href="catlist.php">Category List</a>
          </div>
        </div>
      </li>
      <?php endif?>
      <?php if(Session::get('role') == 1 || Session::get('role') == 2):?>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#post_option"
          aria-expanded="true" aria-controls="category-option">
          <i class="far fa-plus-square"></i>
          <span>Posts Option</span>
        </a>
        <div id="post_option" class="collapse" aria-labelledby="headingBootstrap" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Posts Option</h6>
            <a class="collapse-item" href="addpost.php">Add Post</a>
            <a class="collapse-item" href="postlist.php">Post List</a>
            <a class="collapse-item" href="mypost.php">My Posts</a>
          </div>
        </div>
      </li>
      <?php endif?>

      <?php if(Session::get('role') == 1):?>
      <hr class="sidebar-divider">
      <div class="sidebar-heading">
        Post Option
      </div>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePage" aria-expanded="true"
          aria-controls="collapsePage">
          <i class="fas fa-user-shield"></i>
          <span>Admin Section</span>
        </a>
        <div id="collapsePage" class="collapse" aria-labelledby="headingPage" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Admin</h6>
            <a class="collapse-item" href="adduser.php">Add User</a>
            <a class="collapse-item" href="userlist.php">Users List</a>

          </div>
        </div>
      </li>
      <?php endif?>
      <hr class="sidebar-divider">
      <div class="version" id="version-ruangadmin"></div>
    </ul>
    <!-- Sidebar -->