<?php include "include/header.php"?>
<?php
  if(isset($_REQUEST['submit'])){
    $cat = Helper::inCheck($_REQUEST['addcat']);
    if(empty($cat)){
      $error = "Fild must not be empty!";
    }elseif($db->coutnRow("SELECT * FROM tbl_category WHERE cat_name = ?", [$cat]) > 0){
      $error = "Category Already Exgist";
    }else{
        $addcat = $db->insurt("INSERT INTO tbl_category(cat_name) VALUES(?)", [$cat]);

        if(isset($_REQUEST['nav_cat'])){
          $db->update("UPDATE tbl_category SET show_nav = ? WHERE cat_name = ?", [1, $cat]);
        }
        if(isset($_REQUEST['mega_cat'])){
          $db->update("UPDATE tbl_category SET show_nav_cat = ? WHERE cat_name = ?", [1, $cat]);
        }

        if($addcat){
          $msg = true;
        }
      }
      
    }

?>
        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Add New Category</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item">Pages</li>
              <li class="breadcrumb-item active" aria-current="page">Add New Category</li>
            </ol>
          </div>

          <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Category</h6>
                </div>
                <div class="card-body">
                  <?php if(isset($msg)):?>
                    <div class="alert alert-success alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                      Category Inserted <b>Successfully!</b>
                  </div>
                  <?php elseif(isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                      <?= $error?>
                  </div>
                    <?php endif ?>
                  <form action="" method="POST">

                    <div class="form-group">
                      <label for="title">Add Category</label>
                      <input name="addcat" type="text" class="form-control" id="title"
                         value="">
                    </div>
                    <!-- show on nav -->
                    <div class="custom-control custom-switch">
                          <input name="nav_cat" type="checkbox" class="custom-control-input" id="customSwitch1">
                          <label class="custom-control-label" for="customSwitch1">Show category on navbar</label>
                    </div>
                    <div class="custom-control custom-switch">
                          <input name="mega_cat" type="checkbox" class="custom-control-input" id="customSwitch2">
                          <label class="custom-control-label" for="customSwitch2">Show on Megamenu</label>
                    </div>
                      <!-- submit button -->
                    <button name="submit" type="submit" class="btn btn-primary px-5 mt-4"><b>Save</b></button>
                  </form>
                </div>
              </div>
        </div>
        <!---Container Fluid-->
      </div>
<?php include "include/footer.php"?>