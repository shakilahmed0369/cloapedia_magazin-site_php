<?php
include "../classes/Database.php"; 
$db = new Database; 
if(isset($_REQUEST['delid'])){
  $id = $_REQUEST['delid'];
}

$sql = $db->fetch("SELECT * FROM tbl_post WHERE id = ?", [$id]);
      $main_dir = "../uploads/main_img/";//main dir
      $dir_690x1024 = "../uploads/690x1024/";
      $dir_534x468 = "../uploads/534x468/";
      $dir_533x261 = "../uploads/533x261/";
      $dir_800x460 = "../uploads/800x460/";
      $dir_800x598 = "../uploads/800x598/";
      $dir_800x800 = "../uploads/800x800/";
      $dir_1024x550 = "../uploads/1024x550/";

      $old_img = $sql->image;
      unlink($main_dir.$old_img);
      unlink($dir_690x1024.$old_img);
      unlink($dir_534x468.$old_img);
      unlink($dir_533x261.$old_img);
      unlink($dir_800x460.$old_img);
      unlink($dir_800x598.$old_img);
      unlink($dir_800x800.$old_img);
      unlink($dir_1024x550.$old_img);
$delete = $db->delete("DELETE FROM tbl_post WHERE id = ?", [$id]);
if($delete){
  header("location: postlist.php");
}