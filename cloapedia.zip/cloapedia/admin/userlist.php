<?php include "include/header.php"?>
<?php
if(isset($_REQUEST['delid'])){
  $id = $_REQUEST['delid'];
  $db->delete("DELETE FROM tbl_user WHERE id = ?", [$id]);
}
?>
        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">DataTables</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item">Tables</li>
              <li class="breadcrumb-item active" aria-current="page">DataTables</li>
            </ol>
          </div>

          <!-- Row -->
          <div class="row">

            <!-- DataTable with Hover -->
            <div class="col-lg-12">
              <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">DataTables with Hover</h6>
                </div>
                <div class="table-responsive p-3">
                  <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                    <thead class="thead-light">
                    <tr>
                        <th>NO.</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Personal Name</th>
                        <th>Role</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tfoot>
                      <tr>
                        <th>NO.</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Personal Name</th>
                        <th>Role</th>
                        <th>Action</th>
                      </tr>
                    </tfoot>
                    <tbody>
                      <?php
                        $shows = $db->fetchAll("SELECT * FROM tbl_user");
                        $i = 1;
                        foreach($shows as $show):
                      ?>
                      <tr>
                        <td><?= $i?></td>
                        <td><?= $show->username?></td>
                        <td><?= $show->email?></td>
                        <td><?= $show->name?></td>
                        <td><?php
                        if($show->role == 1){
                          echo "Admin";
                        }elseif($show->role == 2){
                          echo "Author";
                        }elseif($show->role == 3){
                          echo "Editor";
                        }
                        ?></td>
                        <td><a class="btn btn-sm btn-primary" href="edituser.php?editid=<?= $show->id?>"><i class="far fa-edit"></i></a>&nbsp;&nbsp;<a onclick="return confirm('Are you sure you want to Delete?')" class="btn btn-sm btn-danger" href="?delid=<?= $show->id?>"><i class="far fa-trash-alt"></i></a></td>
                        
                        
                       
                        
                      </tr>
                      <?php $i++; endforeach?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
          <!--Row-->

        </div>
        <!---Container Fluid-->
      </div>
<?php include "include/footer.php"?>