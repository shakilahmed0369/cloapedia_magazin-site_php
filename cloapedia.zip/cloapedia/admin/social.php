<?php include "include/header.php"?>
<?php
  if(isset($_REQUEST['submit'])){
    $fb = Helper::inCheck($_REQUEST['fb']);
    $twt = Helper::inCheck($_REQUEST['twt']);
    $ins = Helper::inCheck($_REQUEST['ins']);
    $pen = Helper::inCheck($_REQUEST['pen']);
    $fl = Helper::inCheck($_REQUEST['fl']);
    
    if(!(empty($fb))){
      Helper::social('fb',$fb);
    }if(!empty($twt)){
      Helper::social("twt", "$twt");
    }if(!empty($ins)){
      Helper::social("ins", "$ins");
    }if(!empty($pen)){
      Helper::social("pen", "$pen");
    }if(!empty($twt)){
      Helper::social("fl", "$fl");
    }
    $msg = TRUE;

  }
  $social = $db->fetch("SELECT * FROM tbl_social WHERE id = 1");
?>


        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Update Social Links</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item">Pages</li>
              <li class="breadcrumb-item active" aria-current="page">Update Social Links</li>
            </ol>
          </div>

          <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Links</h6>
                </div>
                <div class="card-body">
                  <?php if(isset($msg)):?>
                    <div class="alert alert-success alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                    Link Update <b>Successfully!</b>
                  </div>
                  <?php endif;?>
                  <form action="" method="POST">

                    <div class="form-group">
                      <label for="title">Facebook</label>
                      <input name="fb" type="text" class="form-control" id="title"
                         value="<?= $social->fb?>">
                    </div>

                    <div class="form-group">
                      <label for="title">Twtter</label>
                      <input name="twt" type="text" class="form-control" id="title"
                        value="<?= $social->twt?>">
                    </div>

                    <div class="form-group">
                      <label for="title">Instragram</label>
                      <input name="ins" type="text" class="form-control" id="title"
                          value="<?= $social->ins?>">
                    </div>

                    <div class="form-group">
                      <label for="title">Penterest</label>
                      <input name="pen" type="text" class="form-control" id="title"
                         value="<?= $social->pen?>">
                    </div>

                    <div class="form-group">
                      <label for="title">Flickr</label>
                      <input name="fl" type="text" class="form-control" id="title"
                         value="<?= $social->fl?>">
                    </div>



                      <!-- submit button -->
                    <button name="submit" type="submit" class="btn btn-primary px-5 mt-4"><b>Save</b></button>
                  </form>
                </div>
              </div>


        </div>
        <!---Container Fluid-->
      </div>
<?php include "include/footer.php"?>