<?php
include "../classes/Database.php";
$db = new Database;
if(!isset($_REQUEST['delid']) || $_REQUEST['delid'] == null){
  header('location: catlist.php');
}else{
  $delid = $_REQUEST['delid'];
  $del = $db->delete("DELETE FROM tbl_category WHERE cat_id = ?", [$delid]);
  if($del){
    header('location: catlist.php');
  }
}