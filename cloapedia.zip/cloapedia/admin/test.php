<?php
if(isset($_REQUEST['submit'])){
  if($_FILES['image']['name'] == true){
    echo "working";
  }else{
    echo "not working";
  }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <form action="" method="POST" enctype="multipart/form-data">
  <input type="file" name="image">
  <input name="submit" type="submit">
</form>
</body>
</html>