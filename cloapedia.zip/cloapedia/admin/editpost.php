<?php include "include/header.php"?>
<?php
if(!isset($_REQUEST['editid']) and $_REQUEST['editid'] == null){
  header("location: 404.php");
}else{
  $id = $_REQUEST['editid'];
}

if(isset($_REQUEST['submit'])):
  //error chack
  Validate::checkEditpost($_REQUEST);
  if($_FILES['image']['name'] == true){
    Validate::imageVal($_FILES);
  }
  $errors = Validate::$error;
  //showing errors on font end
  if(isset($errors['allerror'])){
    $error = "All empty filed must be fill";
  }elseif(isset($errors['image'])){
    $error = $errors['image'];
  }
  
  

  //if image fild is set  this query will run
  if(($_FILES['image']['name'] == true)){
    
    if(empty($errors)){
      $cat = Helper::inCheck($_REQUEST['cat']);
      $title = Helper::inCheck($_REQUEST['title']);
      $editor = $_REQUEST['editor1'];
      $tags = Helper::inCheck($_REQUEST['tags']);
      $userid = Session::get('userid');
      $author = Session::get('author');
      
      $image = $_FILES;
      $main_dir = "../uploads/main_img/";//main dir
      $dir_690x1024 = "../uploads/690x1024/";
      $dir_534x468 = "../uploads/534x468/";
      $dir_533x261 = "../uploads/533x261/";
      $dir_800x460 = "../uploads/800x460/";
      $dir_800x598 = "../uploads/800x598/";
      $dir_800x800 = "../uploads/800x800/";
      $dir_1024x550 = "../uploads/1024x550/";
      //fetch old image name and delete it form dir

      $sql = $db->fetch("SELECT * FROM tbl_post WHERE id = ?", [$id]);
      $old_img = $sql->image;
      unlink($main_dir.$old_img);
      unlink($dir_690x1024.$old_img);
      unlink($dir_534x468.$old_img);
      unlink($dir_533x261.$old_img);
      unlink($dir_800x460.$old_img);
      unlink($dir_800x598.$old_img);
      unlink($dir_800x800.$old_img);
      unlink($dir_1024x550.$old_img);
  
      $name = rand(4,10000)."-".$image['image']['name'];
      Resize::image($_FILES);
      Resize::makeImg($main_dir, $name, 690, 1024, $dir_690x1024);
      Resize::makeImg($main_dir, $name, 534, 468, $dir_534x468);
      Resize::makeImg($main_dir, $name, 800, 460, $dir_800x460);
      Resize::makeImg($main_dir, $name, 800, 598, $dir_800x598);
      Resize::makeImg($main_dir, $name, 800, 800, $dir_800x800);
      Resize::makeImg($main_dir, $name, 1024, 550, $dir_1024x550);
  
      
      if(isset($_REQUEST['show_f'])){
        $fpost = 1;
      }else{
        $fpost = 0;
      }
      if(isset($_REQUEST['show_cat'])){
        $ncpost = 1;
      }else{
        $ncpost = 0;
      }
     
      $update = $db->update("UPDATE tbl_post SET cat = ?, title = ?, content = ?, image = ?, author = ?, tags = ?, f_post = ?, n_c_post = ?, userid = ? WHERE id = ?", [$cat,$title, $editor, $name, $author, $tags, $fpost, $ncpost, $userid,$id]);
      if($update){
        $msg = "Post Edited Successfully";
      }
    }
  }else{
    //if image fild is not set  this query will run
    if(empty($errors)){
      $cat = Helper::inCheck($_REQUEST['cat']);
      $title = Helper::inCheck($_REQUEST['title']);
      $editor = $_REQUEST['editor1'];
      $tags = Helper::inCheck($_REQUEST['tags']);
      $userid = Session::get('userid');
      $author = Session::get('author');
      
  
      
      if(isset($_REQUEST['show_f'])){
        $fpost = 1;
      }else{
        $fpost = 0;
      }
      if(isset($_REQUEST['show_cat'])){
        $ncpost = 1;
      }else{
        $ncpost = 0;
      }
     
      $update = $db->update("UPDATE tbl_post SET cat = ?, title = ?, content = ?, author = ?, tags = ?, f_post = ?, n_c_post = ?, userid = ? WHERE id = ?", [$cat,$title, $editor, $author, $tags, $fpost, $ncpost, $userid, $id]);
      if($update){
        $msg = "Post Edited Successfully";
      }
    }
  }
endif;
?>
        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Edit Post</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item">Pages</li>
              <li class="breadcrumb-item active" aria-current="page">Edit Post</li>
            </ol>
          </div>

          <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Edit Post</h6>
                </div>
                <div class="card-body">

                <?php if(isset($msg)):?>
                   <div class="alert alert-success alert-dismissible" role="alert">
                   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                     <span aria-hidden="true">×</span>
                   </button>
                   <?= $msg?>
                 </div>
                 <?php elseif(isset($error)):?>
                  <div class="alert alert-danger alert-dismissible" role="alert">
                   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                     <span aria-hidden="true">×</span>
                   </button>
                   <?= $error?>
                 </div>
                 <?php endif?>
                  <form enctype="multipart/form-data" action="" method="POST">
                    <?php
                      $edit = $db->fetch("SELECT * FROM tbl_post WHERE id = ?", [$id]);
                    ?>
                    <div class="form-group">
                      <label for="title">Title</label>
                      <input name="author" type="hidden">
                      <input value="<?= $edit->title?>" name="title" type="text" class="form-control" id="title"
                        placeholder="Enter Post Title">
                    </div>

                    <div class="form-group">
                      <label for="exampleFormControlSelect1">Category</label>
                      <select name="cat" class="form-control" id="exampleFormControlSelect1">
                        <option value="0" >Select</option>
                        <?php
                        
                        $cats = $db->fetchAll("SELECT * FROM tbl_category");
                        foreach($cats as $cat): 
                        ?>
                        <option <?php
                          if($edit->cat == $cat->cat_id){echo "selected";}
                        ?> value="<?= $cat->cat_id?>"><?= $cat->cat_name?></option>
                        <?php endforeach?>
                      </select>
                    </div>

                    <div class="form-group">
                    <img width="300" class="img-fluid py-3" src="../uploads/800x460/<?= $edit->image?>" alt="">
                     
                      <div class="custom-file">
                        <input name="image" type="file" class="custom-file-input" id="customFile">
                        <label style="box-shadow: none !important; z-index: 0;" class="custom-file-label" for="customFile">Choose file</label>
                      </div>
                    </div>
                   
                    

                    <!-- text aria -->
                    <div class="form-group mt-4">
                    <textarea name="editor1"><?= $edit->content?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="tags">Tags</label>
                        <input value="<?= $edit->tags?>" name="tags" type="text" class="form-control" id="tags" placeholder="Enter Your Post Tags">
                     </div>


                    <!-- Switches -->
                    <div class="custom-control custom-switch">
                        <input  <?php if($edit->f_post == 1){ echo "checked";}?> name="show_f" type="checkbox" class="custom-control-input" id="customSwitch1">
                        <label class="custom-control-label" for="customSwitch1">Featured Post </label>
                    </div>

                    <div class="custom-control custom-switch">
                        <input <?php if($edit->n_c_post == 1){ echo "checked";}?> name="show_cat" type="checkbox" class="custom-control-input" id="customSwitch2">
                        <label class="custom-control-label" for="customSwitch2">Show on Megamenu</label>
                    </div>

                      <!-- submit button -->
                    <button name="submit" type="submit" class="btn btn-primary px-5 mt-4"><b>POST</b></button>
                  </form>
                </div>
              </div>


        </div>
        <!---Container Fluid-->
      </div>
<?php include "include/footer.php"?>