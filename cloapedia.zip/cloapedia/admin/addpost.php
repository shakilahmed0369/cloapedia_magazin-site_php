<?php include "include/header.php"?>
<?php

if(isset($_REQUEST['submit'])):
  //error chack
  Validate::checkpost($_REQUEST,$_FILES);
  $errors = Validate::$error;
  //showing errors on font end
  if(isset($errors['allerror'])){
    $error = "All empty filed must be fill";
  }elseif(isset($errors['image'])){
    $error = $errors['image'];
  }


  if(empty($errors)){
    $cat = Helper::inCheck($_REQUEST['cat']);
    $title = Helper::inCheck($_REQUEST['title']);
    $editor = $_REQUEST['editor1'];
    $tags = Helper::inCheck($_REQUEST['tags']);
    $userid = Session::get('userid');
    $author = Session::get('author');
    
    $image = $_FILES;
    $main_dir = "../uploads/main_img/";//main dir
    $dir_690x1024 = "../uploads/690x1024/";
    $dir_534x468 = "../uploads/534x468/";
    $dir_533x261 = "../uploads/533x261/";
    $dir_800x460 = "../uploads/800x460/";
    $dir_800x598 = "../uploads/800x598/";
    $dir_800x800 = "../uploads/800x800/";
    $dir_1024x550 = "../uploads/1024x550/";

    $name = rand(4,10000)."-".$image['image']['name'];
    Resize::image($_FILES);
    Resize::makeImg($main_dir, $name, 690, 1024, $dir_690x1024);
    Resize::makeImg($main_dir, $name, 534, 468, $dir_534x468);
    Resize::makeImg($main_dir, $name, 533, 261, $dir_533x261);
    Resize::makeImg($main_dir, $name, 800, 460, $dir_800x460);
    Resize::makeImg($main_dir, $name, 800, 598, $dir_800x598);
    Resize::makeImg($main_dir, $name, 800, 800, $dir_800x800);
    Resize::makeImg($main_dir, $name, 1024, 550, $dir_1024x550);

    
    if(isset($_REQUEST['show_f'])){
      $fpost = 1;
    }else{
      $fpost = 0;
    }
    if(isset($_REQUEST['show_cat'])){
      $ncpost = 1;
    }else{
      $ncpost = 0;
    }
    
    $insert = $db->insurt("INSERT INTO tbl_post(cat, title, content, image, author, tags,f_post, n_c_post,userid ) VALUES(?,?,?,?,?,?,?,?,?)", [$cat, $title, $editor, $name,$author, $tags,$fpost,$ncpost, $userid]);
    if($insert){
      $msg = "Post Published Successfully";
    }
  }
endif;
?>
        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Page</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item">Pages</li>
              <li class="breadcrumb-item active" aria-current="page">Blank Page</li>
            </ol>
          </div>

          <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Form Basic</h6>
                </div>
                <div class="card-body">

                <?php if(isset($msg)):?>
                   <div class="alert alert-success alert-dismissible" role="alert">
                   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                     <span aria-hidden="true">×</span>
                   </button>
                   <?= $msg?>
                 </div>
                 <?php elseif(isset($error)):?>
                  <div class="alert alert-danger alert-dismissible" role="alert">
                   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                     <span aria-hidden="true">×</span>
                   </button>
                   <?= $error?>
                 </div>
                 <?php endif?>

                  <form enctype="multipart/form-data" action="" method="POST">

                    <div class="form-group">
                      <label for="title">Title</label>
                      <input name="author" type="hidden">
                      <input value="<?= @Helper::inCheck($_REQUEST['title'])?>" name="title" type="text" class="form-control" id="title"
                        placeholder="Enter Post Title">
                    </div>

                    <div class="form-group">
                      <label for="exampleFormControlSelect1">Category</label>
                      <select name="cat" class="form-control" id="exampleFormControlSelect1">
                        <option value="0" selected >Select</option>
                        <?php
                        $cats = $db->fetchAll("SELECT * FROM tbl_category");
                        foreach($cats as $cat): 
                        ?>
                        <option value="<?= $cat->cat_id?>"><?= $cat->cat_name?></option>
                        <?php endforeach?>
                      </select>
                    </div>

                   
                    <div class="form-group">
                      <div class="custom-file">
                        <input name="image" type="file" class="custom-file-input" id="customFile">
                        <label style="box-shadow: none !important; z-index: 0;" class="custom-file-label" for="customFile">Choose file</label>
                      </div>
                    </div>
                   
                    <!-- <div class="form-group">
                      <label for="author">Author</label>
                      <input readonly type="text" class="form-control" id="author"
                        placeholder="Enter Post Title">
                    </div> -->

                    <!-- text aria -->
                    <div class="form-group mt-4">
                    <textarea name="editor1"><?= @Helper::inCheck($_REQUEST['editor1'])?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="tags">Tags</label>
                        <input value="<?= @Helper::inCheck($_REQUEST['tags'])?>" name="tags" type="text" class="form-control" id="tags" placeholder="Enter Your Post Tags">
                     </div>


                    <!-- Switches -->
                    <div class="custom-control custom-switch">
                        <input name="show_f" type="checkbox" class="custom-control-input" id="customSwitch1">
                        <label class="custom-control-label" for="customSwitch1">Featured Post </label>
                    </div>

                    <div class="custom-control custom-switch">
                        <input name="show_cat" type="checkbox" class="custom-control-input" id="customSwitch2">
                        <label class="custom-control-label" for="customSwitch2">Featured Post </label>
                    </div>

                      <!-- submit button -->
                    <button name="submit" type="submit" class="btn btn-primary px-5 mt-4"><b>POST</b></button>
                  </form>
                </div>
              </div>


        </div>
        <!---Container Fluid-->
      </div>
<?php include "include/footer.php"?>