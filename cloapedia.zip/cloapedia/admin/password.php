<?php include "include/header.php"?>
<?php
$id =  Session::get('userid');
if(isset($_REQUEST['submit'])):

  $newpass = $_REQUEST['newpass'];
  $conpass = $_REQUEST['conpass'];

  $pass = $db->fetch("SELECT * FROM tbl_user WHERE id = ?", [$id]);

    if(empty($newpass) || empty($conpass)){
      $error = "All fileds must be filled";
    }elseif($newpass === $conpass){
    $update = $db->update("UPDATE tbl_user SET password = ? WHERE id = ?",[md5($newpass), $id]);
    $msg = "Password change saved";
    }else{
      $error = "password not match";
    }

endif;


?>
        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Change Password</h1>
          </div>

          <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Change Password</h6>
                </div>
                <div class="card-body">

                <?php if(isset($msg)):?>
                   <div class="alert alert-success alert-dismissible" role="alert">
                   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                     <span aria-hidden="true">×</span>
                   </button>
                   <?= $msg?>
                 </div>
                 <?php elseif(isset($error)):?>
                  <div class="alert alert-danger alert-dismissible" role="alert">
                   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                     <span aria-hidden="true">×</span>
                   </button>
                   <?= $error?>
                 </div>
                 <?php endif?>

                <form enctype="multipart/form-data" action="" method="POST">


                    <div class="form-group">
                      <label for="title">New password</label>
                      <input name="newpass" value="" name="title" type="text" class="form-control" id="title">
                    </div>

                    <div class="form-group">
                      <label for="title">Confirm New password</label>
                      <input name="conpass" value="" name="title" type="text" class="form-control" id="title">
                    </div>

                      <!-- submit button -->
                    <button name="submit" type="submit" class="btn btn-primary px-5 mt-4"><b>SAVE</b></button>
                  </form>
                </div>
              </div>


        </div>
        <!---Container Fluid-->
      </div>
<?php include "include/footer.php"?>