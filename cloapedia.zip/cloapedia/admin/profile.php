<?php include "include/header.php"?>
<?php
$id =  Session::get('userid');
if(isset($_REQUEST['submit'])):
  $fname = $_REQUEST['fname'];
  $username = $_REQUEST['username'];
  $email = $_REQUEST['email'];
  $bio = $_REQUEST['editor1'];
  $image = $_FILES['image']['name'];
  $tmpname = $_FILES['image']['tmp_name'];

  if($image == true){
    if(empty($fname) || empty($username)|| empty($email) || empty($bio)){
      $error = "All fileds must be filled";
    }else{
    move_uploaded_file($tmpname,'../uploads/profile/'.$image);
    $update = $db->update("UPDATE tbl_user SET
    username = ?,
    email = ?,
    name = ?,
    bio = ?,
    image = ?
    WHERE id = ?",[$username, $email, $fname, $bio, $image, $id]);
    $msg = "Profile change saved";
    }

  }else{
    $update = $db->update("UPDATE tbl_user SET
    username = ?,
    email = ?,
    name = ?,
    bio = ?
    WHERE id = ?",[$username, $email, $fname, $bio, $id]);
    $msg = "Profile change saved";
  }
endif;


$show = $db->fetch("SELECT * FROM tbl_user WHERE id = ?", [$id]);

?>
        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Profile Setting</h1>

          </div>

          <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Form Basic</h6>
                </div>
                <div class="card-body">

                <?php if(isset($msg)):?>
                   <div class="alert alert-success alert-dismissible" role="alert">
                   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                     <span aria-hidden="true">×</span>
                   </button>
                   <?= $msg?>
                 </div>
                 <?php elseif(isset($error)):?>
                  <div class="alert alert-danger alert-dismissible" role="alert">
                   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                     <span aria-hidden="true">×</span>
                   </button>
                   <?= $error?>
                 </div>
                 <?php endif?>

                <form enctype="multipart/form-data" action="" method="POST">
                  <div class="form-group">
                    <?php $profile = $db->fetch("SELECT * FROM tbl_user")?>
                    <img width="150" class="mb-4 rounded-circle img-fluid" src="../uploads/profile/<?= $profile->image?>" alt="">
                      <div class="custom-file">
                        <input name="image" type="file" class="custom-file-input" id="customFile">
                        <label style="box-shadow: none !important; z-index: 0;" class="custom-file-label" for="customFile">Choose file</label>
                      </div>
                    </div>

                    <div class="form-group">
                      <label for="title">Full Name</label>
                      <input name="fname" value="<?= $show->name?>" name="title" type="text" class="form-control" id="title">
                    </div>

                    <div class="form-group">
                      <label for="title">User Name</label>
                      <input name="username" value="<?= $show->username?>" name="title" type="text" class="form-control" id="title">
                    </div>

                    <div class="form-group">
                      <label for="title">Your Email</label>
                      <input value="<?= $show->email?>" name="email" value="" type="text" class="form-control" id="title">
                    </div>

                    <!-- text aria -->
                    <div class="form-group mt-4">
                    <label for="title">Bio</label>
                    
                    <textarea name="editor1"><?= $show->bio?></textarea>
                    </div>
                      <!-- submit button -->
                    <button name="submit" type="submit" class="btn btn-primary px-5 mt-4"><b>SAVE</b></button>
                    <a class=" float-right" href="password.php">Change Password</a>
                  </form>
                </div>
              </div>


        </div>
        <!---Container Fluid-->
      </div>
<?php include "include/footer.php"?>