<?php
if(!isset($_REQUEST['editid']) || $_REQUEST['editid'] == null){
  header('location: catlist.php');
}else{
  $catid = $_REQUEST['editid'];
}
?>
<?php include "include/header.php"?>
<?php
  if(isset($_REQUEST['submit'])){
    $cat = Helper::inCheck($_REQUEST['addcat']);
    if(empty($cat)){
      $error = "Fild must not be empty!";
    }else{
        $addcat = $db->update("UPDATE tbl_category SET cat_name = ? WHERE cat_id = ?", [$cat, $catid]);

        if(isset($_REQUEST['nav_cat'])){
          $db->update("UPDATE tbl_category SET show_nav = ? WHERE cat_id = ?", [1, $catid]);
        }else{
          $db->update("UPDATE tbl_category SET show_nav = ? WHERE cat_id = ?", [0, $catid]);
        }
        if(isset($_REQUEST['mega_cat'])){
          $db->update("UPDATE tbl_category SET show_nav_cat = ? WHERE cat_id = ?", [1, $catid]);
        }else{
          $db->update("UPDATE tbl_category SET show_nav_cat = ? WHERE cat_id = ?", [0, $catid]);
        }

        if($addcat){
          $msg = true;
        }
      }
      
    }
    //checking the show_nav and show nav cat are active or not
    $check = $db->fetch("SELECT * FROM tbl_category WHERE cat_id = ?", [$catid]);
    if($check->show_nav == 1){
      $select1 = "checked";
    }
    if($check->show_nav_cat == 1){
      $select2 = "checked";
    }
?>
        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Edit Category</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item">Pages</li>
              <li class="breadcrumb-item active" aria-current="page">Edit Category</li>
            </ol>
          </div>

          <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Category</h6>
                </div>
                <div class="card-body">
                  <?php if(isset($msg)):?>
                    <div class="alert alert-success alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                      Category Updated <b>Successfully!</b>
                  </div>
                  <?php elseif(isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                      <?= $error?>
                  </div>
                    <?php endif ?>
                  <form action="" method="POST">

                    <div class="form-group">
                      <label for="title">Edit Category</label>
                      <?php
                      $show_cat = $db->fetch('SELECT * FROM tbl_category WHERE cat_id = ?',[$catid]);
                      ?>
                      <input name="addcat" type="text" class="form-control" id="title"
                         value="<?= $show_cat->cat_name?>">
                    </div>
                    <!-- show on nav -->
                    <div class="custom-control custom-switch">
                          <input <?= @$select1?> name="nav_cat" type="checkbox" class="custom-control-input" id="customSwitch1">
                          <label class="custom-control-label" for="customSwitch1">Show category on navbar</label>
                    </div>
                    <div class="custom-control custom-switch">
                          <input <?= @$select2?> name="mega_cat" type="checkbox" class="custom-control-input" id="customSwitch2">
                          <label class="custom-control-label" for="customSwitch2">Show on Megamenu</label>
                    </div>
                      <!-- submit button -->
                    <button name="submit" type="submit" class="btn btn-primary px-5 mt-4"><b>Save</b></button>
                  </form>
                  <a class="btn btn-facebook" href="catlist.php">GO Back</a>
                </div>
              </div>
        </div>
        <!---Container Fluid-->
      </div>
<?php include "include/footer.php"?>