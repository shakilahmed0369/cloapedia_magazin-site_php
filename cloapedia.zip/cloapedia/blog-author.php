<?php
if(!isset($_REQUEST['authid']) || $_REQUEST['authid'] == null){
    header("location: 404.php");
}else{
    $id = ($_REQUEST['authid']);
}
?>
<?php include "include/header.php"?>
<?php include "include/navbar.php"?>
<?php
    if(isset($_REQUEST['pageid'])){
        $pageNo = $_REQUEST['pageid'];
    }
    $totalPost = $db->coutnRow("SELECT * FROM tbl_post WHERE userid = ?", [$id]);
    $perPage = 10;
    $nomOfPages = ceil($totalPost / $perPage);
    $offset = ($pageNo-1)*$perPage;
?>
        <div class="page-title wb">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                    <?php
                        $auth = $db->fetch("SELECT * FROM tbl_user WHERE id = ?", [$id]);
                    ?>
                        <h2><i class="fa fa-user"></i> Author by <?= @$auth->name?> <small class="hidden-xs-down hidden-sm-down">Nulla felis eros, varius sit amet volutpat non. </small></h2>
                    </div><!-- end col -->
                    <div class="col-lg-4 col-md-4 col-sm-12 hidden-xs-down hidden-sm-down">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="#">Blog</a></li>
                            <li class="breadcrumb-item active">Author by Jessica</li>
                        </ol>
                    </div><!-- end col -->                    
                </div><!-- end row -->
            </div><!-- end container -->
        </div><!-- end page-title -->

        <section class="section wb">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 col-md-12 col-sm-12 col-xs-12">
                        <div class="page-wrapper">
                            <div class="custombox authorbox clearfix">
                                <h4 class="small-title">About author</h4>
                                
                                <div class="row">
                                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                                        <img src="uploads/profile/<?= @$auth->image?>" alt="" class="img-fluid rounded-circle"> 
                                    </div><!-- end col -->
                                    
                                    <div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
                                        <h4><a href="#"><?= @$auth->name?></a></h4>
                                        <p><?= @$auth->bio?></p>

                                        <div class="topsocial">
                                            <a href="#" data-toggle="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook"></i></a>
                                            <a href="#" data-toggle="tooltip" data-placement="bottom" title="Youtube"><i class="fa fa-youtube"></i></a>
                                            <a href="#" data-toggle="tooltip" data-placement="bottom" title="Pinterest"><i class="fa fa-pinterest"></i></a>
                                            <a href="#" data-toggle="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter"></i></a>
                                            <a href="#" data-toggle="tooltip" data-placement="bottom" title="Instagram"><i class="fa fa-instagram"></i></a>
                                            <a href="#" data-toggle="tooltip" data-placement="bottom" title="Website"><i class="fa fa-link"></i></a>
                                        </div><!-- end social -->
                                    </div><!-- end col -->
                                </div><!-- end row -->
                            </div><!-- end author-box -->
                            <hr class="invis1">
                        <?php 
                        $posts = $db->fetchAll("SELECT * FROM tbl_post WHERE userid = ? limit $offset, $perPage", [$id]);
                        if($posts):
                        foreach($posts as $post):
                        ?>
                            <div class="blog-custom-build">
                                <div class="blog-box">
                                    <div class="post-media">
                                        <a href="page.php?postid=<?= $post->id?>" title="">
                                            <img src="uploads/800x460/<?= $post->image?>" alt="" class="img-fluid">
                                            <div class="hovereffect">
                                                <span></span>
                                            </div>
                                            <!-- end hover -->
                                        </a>
                                    </div>
                                    <!-- end media -->
                                    <div class="blog-meta big-meta text-center">

                                        <div class="post-sharing">
                                            <ul class="list-inline">
                                                <li><a href="#" class="fb-button btn btn-primary"><i class="fa fa-facebook"></i> <span class="down-mobile">Share on Facebook</span></a></li>
                                                <li><a href="#" class="tw-button btn btn-primary"><i class="fa fa-twitter"></i> <span class="down-mobile">Tweet on Twitter</span></a></li>
                                                <li><a href="#" class="gp-button btn btn-primary"><i class="fa fa-google-plus"></i></a></li>
                                            </ul>
                                        </div><!-- end post-sharing -->
                                        <h4><a href="page.php?postid=<?= $post->id?>" title=""><?= $post->title?></a></h4>
                                        <p><?= $helper->textShort($post->content, 250)?></p>
                                        <small><a href="blog-category-01.html" title=""><?= Helper::showcat($post->cat)?></a></small>
                                        <small><a href="page.php?postid=<?= $post->id?>" title=""><?= $helper->formatDate($post->date)?></a></small>
                                        <small><a href="blog-author.php?authid=<?= $post->userid?>" title=""><?= $post->author?></a></small>
                                        <small><a href="blog-author.html" title=""><i class="fa fa-eye"></i> 2291</a></small>
                                    </div><!-- end meta -->
                                </div><!-- end blog-box -->
                                <hr class="invis">
                            </div><!-- end blog-custom-build -->
                            <?php endforeach?>
                            <?php endif?>
                        </div><!-- end page-wrapper -->

                        <hr class="invis">
                        <div class="row">
                            <div class="col-md-12">
                                <nav aria-label="Page navigation">
                                    <ul class="pagination justify-content-start">
                                    <?php
                                        for($i = 1; $i<= $nomOfPages; $i++):
                                        ?>
                                        <li class="page-item"><a class="page-link" href="blog-author.php?authid=<?= $id?>&pageid=<?=$i?>"><?=$i?></a></li>
                                        <?php endfor?>
                                            <a class="page-link" href="#">Next</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div><!-- end col -->
                        </div><!-- end row -->
                    </div><!-- end col -->
                     <!-- sidebar starts here -->
                     <?php include "include/sidebar.php"?>
                     <!-- sidebar End here -->

                </div><!-- end row -->
            </div><!-- end container -->
        </section>

<?php include "include/footer.php"?>