<?php
if(!isset($_REQUEST['catid']) || $_REQUEST['catid'] == NULL){
    header("location: 404.php");
}else{
    $catid = $_REQUEST['catid'];
}
?>
<?php include "include/header.php"?>
<?php include "include/navbar.php"?>
<?php
//$posts = $db->fetchAll("SELECT * FROM tbl_post WHERE cat = ?", [$catid]);
if(isset($_REQUEST['page'])){
    $pageNo = $_REQUEST['page'];
}
$totalPost = $db->coutnRow("SELECT * FROM tbl_post WHERE cat = ?", [$catid]);
$perPage = 10;
$nomOfPages = ceil($totalPost / $perPage);
$offset = ($pageNo-1)*$perPage;
?>




        <div class="page-title wb">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                        <?php
                        $cat = $db->fetch("SELECT * FROM tbl_category WHERE cat_id = ?", [$catid]);
                        ?>
                        <h2><i class="fa fa-shopping-bag bg-red"></i> <?= $cat->cat_name?><small class="hidden-xs-down hidden-sm-down">Nulla felis eros, varius sit amet volutpat non. </small></h2>
                    </div><!-- end col -->
                    <div class="col-lg-4 col-md-4 col-sm-12 hidden-xs-down hidden-sm-down">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="#">Blog</a></li>
                            <li class="breadcrumb-item active"><?= $cat->cat_name?></li>
                        </ol>
                    </div><!-- end col -->                    
                </div><!-- end row -->
            </div><!-- end container -->
        </div><!-- end page-title -->

        <section class="section wb">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 col-md-12 col-sm-12 col-xs-12">
                        <div class="page-wrapper">
                            <div class="blog-list clearfix">
                            <?php
                            $posts = $db->fetchAll("SELECT * FROM tbl_post WHERE cat = ? limit $offset, $perPage", [$catid]);
                            foreach($posts as $post):
                            ?>

                                <div class="blog-box row">
                                    <div class="col-md-4">
                                        <div class="post-media">
                                            <a href="single.html" title="">
                                                <img src="uploads/800x800/<?= $post->image?>" alt="" class="img-fluid">
                                                <div class="hovereffect"></div>
                                            </a>
                                        </div><!-- end media -->
                                    </div><!-- end col -->

                                    <div class="blog-meta big-meta col-md-8">
                                        <h4><a href="page.php?postid=<?= $post->id?>" title=""><?= $post->title?></a></h4>
                                        <p><?= $helper->textShort($post->content, 200)?></p>
                                        
                                        <small><a href="" title=""><?= $cat->cat_name?></a></small>
                                        <small><a href="" title=""><?= $helper->formatDate($post->date)?></a></small>
                                        <small><a href="blog-author.php?authid=<?= $post->userid?>" title=""><?= $post->author?></a></small>
                                    </div><!-- end meta -->
                                </div><!-- end blog-box -->
                                <hr class="invis">
                                <?php endforeach?>


                                <div class="row">
                                    <div class="col-lg-10 offset-lg-1">
                                        <div class="banner-spot clearfix">
                                            <div class="banner-img">
                                                <img src="upload/banner_02.jpg" alt="" class="img-fluid">
                                            </div><!-- end banner-img -->
                                        </div><!-- end banner -->
                                    </div><!-- end col -->
                                </div><!-- end row -->


                        
                            </div><!-- end blog-list -->
                        </div><!-- end page-wrapper -->

                        <hr class="invis">

                        

                        <div class="row">
                            <div class="col-md-12">
                                <nav aria-label="Page navigation">
                                    <ul class="pagination justify-content-start">
                                        <?php
                                        for($i = 1; $i<= $nomOfPages; $i++):
                                        ?>
                                        <li class="page-item"><a class="page-link" href="category.php?catid=<?= $catid?>&page=<?=$i?>"><?=$i?></a></li>
                                        <?php endfor?>
                                            <a class="page-link" href="#">Next</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div><!-- end col -->
                        </div><!-- end row -->
                    </div><!-- end col -->

                    <!-- sidebar starts here -->
                    <?php include "include/sidebar.php"?>
                    <!-- sidebar End here -->

                </div><!-- end row -->
            </div><!-- end container -->
        </section>
<?php include "include/footer.php"?>