<div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
                        <div class="sidebar">
                            <div class="widget">
                                <h2 class="widget-title">Search</h2>
                                <form method="POST" action="search.php" class="form-inline search-form">
                                    <div class="form-group">
                                        <input name="search" type="text" class="form-control" placeholder="Search on the site">
                                    </div>
                                    <button name="submit" type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
                                </form>
                            </div><!-- end widget -->

                            <div class="widget">
                                <h2 class="widget-title">Recent Posts</h2>
                                <div class="blog-list-widget">
                                    <div class="list-group">
                                        <?php
                                        $posts = $db->fetchAll("SELECT * FROM tbl_post ORDER BY id DESC limit 4");
                                        foreach($posts as $post):
                                        ?>
                                        <a href="single.html" class="list-group-item list-group-item-action flex-column align-items-start">
                                            <div class="w-100 justify-content-between">
                                                <img src="uploads/800x800/<?= $post->image?>" alt="" class="img-fluid float-left">
                                                <h5 class="mb-1"><?= $post->title?></h5>
                                                <small><?= $helper->formatDate($post->date)?></small>
                                            </div>
                                        </a>
                                        <?php endforeach?>
                                    </div>
                                </div><!-- end blog-list -->
                            </div><!-- end widget -->

                            <div class="widget">
                                <h2 class="widget-title">Advertising</h2>
                                <div class="banner-spot clearfix">
                                    <div class="banner-img">
                                        <img src="upload/banner_03.jpg" alt="" class="img-fluid">
                                    </div><!-- end banner-img -->
                                </div><!-- end banner -->
                            </div><!-- end widget -->

                            <div class="widget">
                                <h2 class="widget-title">Popular Categories</h2>
                                <div class="link-widget">
                                    <ul>
                                        <?php
                                        $cats = $db->fetchAll("SELECT * FROM tbl_category ORDER BY cat_id DESC limit 15");
                                        foreach($cats as $cat):
                                        $posts = $db->fetchAll("SELECT * FROM tbl_post WHERE cat = ?", [$cat->cat_id]);
                                        ?>
                                        <li><a href="category.php?catid=<?= $cat->cat_id?>&page=1"><?= $cat->cat_name?> <span>(<?= count($posts)?>)</span></a></li>
                                        <?php endforeach?>
                                    </ul>
                                </div><!-- end link-widget -->
                            </div><!-- end widget -->
                        </div><!-- end sidebar -->
                    </div><!-- end col -->