<header class="header">
<div class="container">
<nav class="navbar navbar-inverse navbar-toggleable-md">
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#cloapediamenu" aria-controls="cloapediamenu" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse justify-content-md-center" id="cloapediamenu">
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link color-pink-hover" href="index.php">Home</a>
</li>
<li class="nav-item dropdown has-submenu menu-large hidden-md-down hidden-sm-down hidden-xs-down">
    <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Categories</a>
    <ul class="dropdown-menu megamenu" aria-labelledby="dropdown01">
        <li>
            <div class="mega-menu-content clearfix">
                <div class="tab">
                <!-- category featching from database -->
                    <?php $i=1; foreach(Helper::get_cat(1,0,5) as $cat): ?>
                        <button class="tablinks <?php if($i==1){echo 'active';}?>" onclick="openCategory(event, '<?= $cat->cat_id?>')"><?= $cat->cat_name?></button>
                    <?php $i++; endforeach; ?>
                    </div>
                <div class="tab-details clearfix">
                <!-- category featching on post -->
                <?php $i=1; foreach(Helper::get_cat(1, 0, 5) as $cat):?>
                        <div id="<?= $cat->cat_id?>" class="tabcontent <?php if($i==1){echo 'active';}?>">
                            <div class="row">
                            <!-- post featching from database -->
                            <?php foreach(Helper::get_post($cat->cat_id, 0, 4) as $post):?>
                                <div class="col-lg-3 col-md-6 col-sm-12 col-xs-12">
                                    <div class="blog-box">
                                        <div class="post-media">
                                            <a href="page.php?postid=<?= $post->id?>" title="">
                                                <img src="uploads/800x460/<?= $post->image?>" alt="" class="img-fluid">
                                                <div class="hovereffect">
                                                </div><!-- end hover -->
                                                <span class="menucat"><?= $cat->cat_name?></span>
                                            </a>
                                        </div><!-- end media -->
                                        <div class="blog-meta">
                                            <h4><a href="page.php?postid=<?= $post->id?>" title=""><?= $post->title?></a></h4>
                                        </div><!-- end meta -->
                                    </div><!-- end blog-box -->
                                </div> 
                            <?php endforeach; ?>
                        </div><!-- end row -->
                        </div>
                    <?php $i++; endforeach; ?>
                </div><!-- end tab-details -->
            </div><!-- end mega-menu-content -->
        </li>
    </ul>
</li>

        
<?php $rows = $db->fetchAll('SELECT * FROM tbl_category WHERE  show_nav = ?', ['1']);
    if($rows){ 
        foreach($rows as $row){
        ?>

    <li class="nav-item">
        <a class="nav-link color-pink-hover" href="category.php?catid=<?= $row->cat_id?>&page=1"><?= $row->cat_name?></a>
    </li>
    <?php } }?>
</ul>
</div>
</nav>
</div><!-- end container -->
</header><!-- end header -->